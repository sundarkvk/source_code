Github-To-Go
============

Universal iOS Github client application

See the tutorial screencast at: http://youtu.be/Xc3JqwbUuDw
